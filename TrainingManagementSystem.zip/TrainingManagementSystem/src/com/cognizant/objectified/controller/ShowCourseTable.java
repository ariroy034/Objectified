package com.cognizant.objectified.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.objectified.dao.CoursesDaoImpl;
import com.cognizant.objectified.model.Courses;

/**
 * Servlet implementation class ShowTable
 */
@WebServlet("/ShowTable")
public class ShowCourseTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
    List<Courses> courseList = new ArrayList<>();   
	CoursesDaoImpl dao = new CoursesDaoImpl();
    public ShowCourseTable() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		courseList = dao.searchCourses();
			request.setAttribute("courseList",courseList);
	        RequestDispatcher view = request.getRequestDispatcher("Courses.jsp");
	          view.forward(request, response);
		}
	}


