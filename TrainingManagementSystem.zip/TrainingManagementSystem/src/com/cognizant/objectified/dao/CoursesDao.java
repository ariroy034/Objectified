package com.cognizant.objectified.dao;

import java.util.List;

import com.cognizant.objectified.model.Courses;

public interface CoursesDao {
	String addCourses(String name,String mode,String desc);
	String deleteCourses(int id);
	List<Courses> searchCourses();
}
