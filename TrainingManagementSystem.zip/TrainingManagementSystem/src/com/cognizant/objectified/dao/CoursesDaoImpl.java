package com.cognizant.objectified.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.cts.claims.util.DBConstants;
import org.cts.claims.util.DBUtil;

import com.cognizant.objectified.model.Courses;

public class CoursesDaoImpl implements CoursesDao{
	Connection connection=null;
	@Override
	public String addCourses(String name, String mode,String desc) {
		String message = null;
		try {
			connection = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME , DBConstants.PWD);
			PreparedStatement preparedStatement = connection.prepareStatement("insert into courses(name,mode,description) values(?,?,?)");
			preparedStatement.setString(1,name);
			preparedStatement.setString(2,mode);
			preparedStatement.setString(3,desc);
			int flag  = preparedStatement.executeUpdate();
			if(flag > 0)
				message = "success";
			else
				message = "not success";
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return message;
	}
		

	@Override
	public String deleteCourses(int id) {
		String message = null;
		
		try {
			connection = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME , DBConstants.PWD);
			PreparedStatement preparedStatement = connection.prepareStatement("delete from courses where id=?");
			preparedStatement.setInt(1,id);
			int flag  = preparedStatement.executeUpdate();
			if(flag > 0)
				message = "success";
			else
				message = "not success";
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return message;
		
	}

	@Override
	public List<Courses> searchCourses() {
		List<Courses> courseList  = new ArrayList<>();
		  try {
			    connection = DBUtil.getConnection(DBConstants.DRIVER, DBConstants.URL,DBConstants.UNAME , DBConstants.PWD);
				PreparedStatement preparedStatement = connection.prepareStatement("select name,mode,description from courses");
				ResultSet resultSet  = preparedStatement.executeQuery();
				while(resultSet.next())
				courseList.add(new Courses(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3)));
				connection.close();  
				
		  }
		  catch (Exception e) {
			  e.printStackTrace();
		  }
		// TODO Auto-generated method stub
		return courseList;
	}
		
	
}
