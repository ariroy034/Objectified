package com.cognizant.objectified.model;

public class Courses {
	String name;
	String mode;
	String desc;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Courses(String name, String mode, String desc) {
		super();
		this.name = name;
		this.mode = mode;
		this.desc = desc;
	}
}
